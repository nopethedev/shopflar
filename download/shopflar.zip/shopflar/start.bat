@echo off
echo ==========================================
echo   Shopflar - Quick Start (Windows)
echo ==========================================

where bun >nul 2>&1
if %ERRORLEVEL% EQU 0 (
  set PM=bun
) else (
  where npm >nul 2>&1
  if %ERRORLEVEL% EQU 0 (
    set PM=npm
  ) else (
    echo Neither bun nor npm found. Install Node.js 18+ first.
    exit /b 1
  )
)

echo Installing dependencies...
call %PM% install
echo Generating Prisma client...
call %PM% run db:generate
echo Creating database tables...
call %PM% run db:push
echo Seeding demo data...
call %PM% run db:seed

echo.
echo ==========================================
echo   Setup complete!
echo ==========================================
echo.
echo Demo accounts:
echo   Admin:    admin@shopflar.dev / admin12345
echo   Customer: customer@example.com / customer123
echo.
echo Start with: %PM% run dev
echo Then open http://localhost:3000
pause
