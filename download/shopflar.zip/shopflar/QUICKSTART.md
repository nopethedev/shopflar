# Shopflar — Quick Start

The fastest way to get Shopflar running locally:

## Option A: Use the start script

**Mac/Linux:**
```bash
./start.sh
bun run dev    # or: npm run dev
```

**Windows:**
```bat
start.bat
npm run dev
```

The script automatically installs dependencies, creates the database, and seeds demo data.

## Option B: Manual setup

```bash
# 1. Install dependencies (Bun recommended, npm works too)
bun install          # or: npm install

# 2. Generate Prisma client + create SQLite database
bun run db:generate
bun run db:push

# 3. Seed demo data (creates products, categories, admin user, etc.)
bun run db:seed

# 4. Start the dev server
bun run dev          # or: npm run dev
```

## Open the app

- **Storefront**: http://localhost:3000
- **Admin panel**: http://localhost:3000/admin

## Demo accounts

| Role | Email | Password |
|------|-------|----------|
| Super Admin | `admin@shopflar.dev` | `admin12345` |
| Customer | `customer@example.com` | `customer123` |

## Try the discount codes

- `WELCOME10` — 10% off, no minimum
- `SAVE25` — 25% off, $150 min (capped at $75)
- `FREESHIP` — Free shipping

## What's already working

- Browse the storefront, add products to cart, checkout with Cash on Delivery
- Admin dashboard with revenue chart, recent orders, low-stock alerts
- Full product editor with 8 tabs (general, images, pricing, inventory, variants, categories, SEO, shipping)
- Appearance editor — change colors, hero image, fonts, social links live
- Newsletter, shipping, tax, discount management
- Customer accounts with order history & saved addresses

## What needs API keys (optional)

- **Stripe** — add `STRIPE_SECRET_KEY`, `STRIPE_PUBLISHABLE_KEY`, `STRIPE_WEBHOOK_SECRET` to `.env` and restart
- **PayPal** — add `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_WEBHOOK_ID` to `.env` and restart
- **Printify** — add `PRINTIFY_API_KEY` to `.env` and restart
- **Supabase** — for production; switch Prisma provider to `postgresql` and set `DATABASE_URL`

See `README.md` for full documentation on each integration.

## Requirements

- Node.js 18+ (or Bun — recommended, faster)
- That's it. SQLite is bundled, no external database needed for local dev.

## Production deployment

See `README.md` → "Production Deployment" section for Vercel/Docker/self-hosted instructions.
