import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth'
import { sendEmail } from '@/lib/email'

export async function POST(req) {
  try {
    await requireAdmin()
    const { to } = await req.json()
    if (!to) return NextResponse.json({ error: 'Email required' }, { status: 400 })

    const result = await sendEmail({
      to,
      subject: 'Test email from Shopflar',
      html: `
        <div style="font-family: sans-serif; padding: 20px;">
          <h1>Test Email ✓</h1>
          <p>If you received this, your SMTP configuration is working correctly.</p>
          <p>Sent at: ${new Date().toISOString()}</p>
        </div>
      `
    })

    if (result.success) {
      return NextResponse.json({ success: true, messageId: result.messageId })
    } else {
      return NextResponse.json({ success: false, error: result.error }, { status: 400 })
    }
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
