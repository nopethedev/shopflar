// File upload endpoint — saves files to /public/uploads/ and returns the URL
// Supports images (for product images, hero, etc.) and files (for downloadable products)
import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth'
import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads')
const MAX_IMAGE_SIZE = 10 * 1024 * 1024 // 10MB for images
const MAX_FILE_SIZE = 100 * 1024 * 1024 // 100MB for download files

const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml']
const FILE_EXTENSIONS = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
  'image/svg+xml': '.svg',
  'application/pdf': '.pdf',
  'application/zip': '.zip',
  'application/x-zip-compressed': '.zip',
  'application/x-rar-compressed': '.rar',
  'application/octet-stream': '', // fallback — use original extension
  'text/plain': '.txt',
  'application/epub+zip': '.epub',
  'audio/mpeg': '.mp3',
  'video/mp4': '.mp4'
}

export async function POST(req) {
  try {
    await requireAdmin()

    const formData = await req.formData()
    const file = formData.get('file')
    const type = formData.get('type') || 'image' // image | file

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    // Validate file size
    const maxSize = type === 'image' ? MAX_IMAGE_SIZE : MAX_FILE_SIZE
    if (file.size > maxSize) {
      const maxMB = maxSize / (1024 * 1024)
      return NextResponse.json({ error: `File too large. Max ${maxMB}MB` }, { status: 400 })
    }

    // Validate file type for images
    if (type === 'image' && !IMAGE_TYPES.includes(file.type)) {
      return NextResponse.json({ error: `Invalid image type. Allowed: JPG, PNG, WebP, GIF, SVG` }, { status: 400 })
    }

    // Ensure upload directory exists
    if (!existsSync(UPLOAD_DIR)) {
      await mkdir(UPLOAD_DIR, { recursive: true })
    }

    // Generate unique filename
    const ext = FILE_EXTENSIONS[file.type] || path.extname(file.name) || ''
    const safeName = file.name.replace(/[^a-zA-Z0-9.-]/g, '-').toLowerCase().slice(0, 50)
    const uniqueId = randomBytes(6).toString('hex')
    const filename = `${Date.now()}-${uniqueId}-${safeName}${ext && !safeName.endsWith(ext) ? ext : ''}`

    const filepath = path.join(UPLOAD_DIR, filename)
    const bytes = await file.arrayBuffer()
    await writeFile(filepath, Buffer.from(bytes))

    // Return the public URL
    const url = `/uploads/${filename}`

    return NextResponse.json({
      url,
      filename,
      size: file.size,
      type: file.type
    })
  } catch (e) {
    console.error('Upload error:', e)
    return NextResponse.json({ error: e.message || 'Upload failed' }, { status: 500 })
  }
}
