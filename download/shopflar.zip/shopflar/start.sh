#!/usr/bin/env bash
# Quick start script for Shopflar
set -e

echo "=========================================="
echo "  Shopflar - Quick Start"
echo "=========================================="

# Check for node/bun
if command -v bun >/dev/null 2>&1; then
  PM="bun"
  echo "✓ Using Bun"
elif command -v npm >/dev/null 2>&1; then
  PM="npm"
  echo "✓ Using npm"
else
  echo "✗ Neither bun nor npm found. Install Node.js 18+ first."
  exit 1
fi

# Install dependencies
echo ""
echo "[1/4] Installing dependencies..."
if [ "$PM" = "bun" ]; then
  bun install
else
  npm install
fi

# Generate Prisma client
echo ""
echo "[2/4] Generating Prisma client..."
if [ "$PM" = "bun" ]; then
  bun run db:generate
else
  npm run db:generate
fi

# Push schema to SQLite
echo ""
echo "[3/4] Creating database tables..."
if [ "$PM" = "bun" ]; then
  bun run db:push
else
  npm run db:push
fi

# Seed demo data
echo ""
echo "[4/4] Seeding demo data..."
if [ "$PM" = "bun" ]; then
  bun run db:seed
else
  npm run db:seed
fi

echo ""
echo "=========================================="
echo "  ✅ Setup complete!"
echo "=========================================="
echo ""
echo "Demo accounts:"
echo "  Admin:    admin@shopflar.dev / admin12345"
echo "  Customer: customer@example.com / customer123"
echo ""
echo "Start the dev server with:"
echo "  $PM run dev"
echo ""
echo "Then open http://localhost:3000"
echo "Admin panel: http://localhost:3000/admin"
